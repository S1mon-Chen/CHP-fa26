#!/usr/bin/env bash
set -euo pipefail
exec bash "$(dirname "$0")/../assignment6/scripts/run.sh" "$@"
